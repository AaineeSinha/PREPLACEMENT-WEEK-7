
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

// Simple brute-force count of substrings with exactly K distinct characters
int countKDistinct(char str[], int k) {
    int n = strlen(str), count = 0;
    for (int i = 0; i < n; i++) {
        int freq[256] = {0}, distinct = 0;
        for (int j = i; j < n; j++) {
            if (freq[(unsigned char)str[j]] == 0) distinct++;
            freq[(unsigned char)str[j]]++;
            if (distinct == k) count++;
            else if (distinct > k) break;
        }
    }
    return count;
}

int main() {
    char str[100];
    int k;
    printf("Enter string: ");
    scanf("%s", str);
    printf("Enter K: ");
    scanf("%d", &k);
    printf("Count of substrings with exactly %d distinct chars = %d\n", k, countKDistinct(str, k));
    return 0;
}
